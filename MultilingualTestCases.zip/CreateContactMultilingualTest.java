package tests;

import org.testng.annotations.Test;

import createcontactmultilingualpages.LoginPageMultilingual;
import hooksformultilingual.BasePage;

public class CreateContactMultilingualTest extends BasePage {
	@Test
	public void createContactMultilingualTest() {
		new LoginPageMultilingual()
		.typeUserName("Democsr2")
		.typePassword("crmsfa")
		.clickLogin1()
		.clickCRMSFA()
		.clickContacts()
		.clickCreateContact()
		.typeFirstName("Abinaya")
		.typeLastName("Shree")
		.typeFirstNameLocal("Sudheera")
		.typeLastNameLocal("Shri")
		.typeDepartmentName("EIE")
		.typeDescription("Electronics and Instrumentation Engineering")
		.typeprimaryEmail("sudheera96@gmail.com")
		.clickCreateContactButton()
		.clickEditButton()
		.clearAndTypeDescription()
		.clickUpdateContact()
		.verifyContact();
	}

}
