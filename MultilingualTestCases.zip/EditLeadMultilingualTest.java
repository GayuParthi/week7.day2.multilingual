package tests;

import org.testng.annotations.Test;

import editleadmultilingualpages.LoginPage2Multilingual;
import hooksformultilingual.BasePage;

public class EditLeadMultilingualTest extends BasePage{
	@Test
	public void EditLeadMultilingual() throws InterruptedException {
		new LoginPage2Multilingual()
		.typeUserName("DemoCsr2")
		.typePassword("crmsfa")
		.clickLogin1()
		.clickCRMSFA3()
		.clickLeads()
		.clickFindLeads()
		.typeFirstName("Hari")
		.clickFindLeadsButton()
		.clickFirstLeadId()
		.clickEditButton()
		.clearCompanyName()
		.updateCompanyName("TestLeaf")
		.clickUpdateButton1()
		.verifyUpdatedCompanyName();
		
	}

}
