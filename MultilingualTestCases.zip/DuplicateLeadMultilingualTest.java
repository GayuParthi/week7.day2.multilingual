package tests;

import org.testng.annotations.Test;

import duplicateleadmultilingual.LoginPage3Multilingual;
import hooksformultilingual.BasePage;

public class DuplicateLeadMultilingualTest extends BasePage{
	@Test
	public void duplicateLeadMultilingual() throws InterruptedException {
		new LoginPage3Multilingual()
		.typeUserName("DemoCsr2")
		.typePassword("crmsfa")
		.clickLogin3()
		.clickCRMSFA3()
		.clickLeads()
		.clickFindLeads()
		.clickEmail1()
		.typeEmailAddress3("aaa@gmail.com")
	     .clickFindLeadsButton4()
	     .clickFirstLeadId3()
	     .clickDuplicateButton2()
	     .verifyDuplicateLead3()
	     .clickCreateLead3()
	     .viewLead_FirstName()
	     .verify_Captured_LeadId();
	}

}
