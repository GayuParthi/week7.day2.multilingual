package duplicateleadmultilingual;

import org.openqa.selenium.By;

import hooksformultilingual.BasePage;

public class ViewLeadsPage3Multilingual extends BasePage{
	public DuplicateLeadPage1Multilingual clickDuplicateButton2() {
		getDriver().findElement(By.linkText(prop1.getProperty("DuplicateLead"))).click();
		return new DuplicateLeadPage1Multilingual();
	}

}
