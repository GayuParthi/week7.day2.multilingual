package duplicateleadmultilingual;

import org.openqa.selenium.By;

import hooksformultilingual.BasePage;

public class HomePage3Multilingual extends BasePage {
	public LeadsPage1Multilingual clickCRMSFA3() {
		getDriver().findElement(By.linkText("CRM/SFA")).click();
		return new LeadsPage1Multilingual();
	}

}
