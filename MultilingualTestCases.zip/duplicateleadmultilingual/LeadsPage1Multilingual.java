package duplicateleadmultilingual;

import org.openqa.selenium.By;

import hooksformultilingual.BasePage;

public class LeadsPage1Multilingual extends BasePage {
	public LeadsPage1Multilingual clickLeads() {
		getDriver().findElement(By.linkText(prop1.getProperty("Leads"))).click();
		return this;
	}
	public FindLeadsPage1Multilingual clickFindLeads() {
		getDriver().findElement(By.linkText(prop1.getProperty("FindLeads"))).click();
		return new FindLeadsPage1Multilingual();
	}
}
