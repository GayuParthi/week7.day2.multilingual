package duplicateleadmultilingual;

import org.openqa.selenium.By;

import hooksformultilingual.BasePage;

public class DuplicateLeadPage1Multilingual extends BasePage {
	public DuplicateLeadPage1Multilingual verifyDuplicateLead3() {
		if(getDriver().getTitle().contains("Duplicate Lead")) {
			System.out.println("The title contains the word Duplicate Lead");
		}else {
			System.out.println("The title does not contain the word Duplicate Lead");
		}
		return this;
	}
	public ViewLeadsPage4Multilingual clickCreateLead3() {
		getDriver().findElement(By.name("submitButton")).click();
		return new ViewLeadsPage4Multilingual();
	}

}
