package duplicateleadmultilingual;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import hooksformultilingual.BasePage;

public class FindLeadsPage1Multilingual extends BasePage{
	public FindLeadsPage1Multilingual clickEmail1() {
		getDriver().findElement(By.linkText("Email")).click();
		return this;
	}
	public FindLeadsPage1Multilingual typeEmailAddress3(String email) {
		getDriver().findElement(By.name("emailAddress")).sendKeys(email);
		return this;
	}
	public FindLeadsPage1Multilingual clickFindLeadsButton4() throws InterruptedException {
		getDriver().findElement(By.linkText(prop1.getProperty("FindLeadsButton"))).click();
		Thread.sleep(2000);
		return this;
	}
	public ViewLeadsPage3Multilingual clickFirstLeadId3() {
		WebElement leadFirstName = getDriver().findElement(By.xpath("(//div[@class='x-grid3-cell-inner x-grid3-col-firstName'])[1]/a"));
		String capturedLeadName = leadFirstName.getText();
		System.out.println(capturedLeadName);
		leadFirstName.click();
		return new ViewLeadsPage3Multilingual();
	}

}
