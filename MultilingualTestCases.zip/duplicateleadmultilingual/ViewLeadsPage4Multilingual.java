package duplicateleadmultilingual;

import org.openqa.selenium.By;

import hooksformultilingual.BasePage;

public class ViewLeadsPage4Multilingual extends BasePage {
	String capturedLeadName;
	String duplicatedLeadName;
	public ViewLeadsPage4Multilingual viewLead_FirstName() {
		String duplicatedLeadName = getDriver().findElement(By.id("viewLead_firstName_sp")).getText();
		System.out.println(duplicatedLeadName);
		return this;
	}
	public ViewLeadsPage4Multilingual verify_Captured_LeadId() {
		
		Object capturedLeadName = getDriver();
		Object duplicatedLeadName = getDriver();
		if(capturedLeadName.equals(duplicatedLeadName)) {
	    	System.out.println("Duplicated lead name is same as Captured name");
	    }else {
	    	System.out.println("Duplicated lead name is not same as Captured name");
	    }
		return this;
	}
	

}
