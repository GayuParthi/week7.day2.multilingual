package editleadmultilingualpages;

import org.openqa.selenium.By;

import hooksformultilingual.BasePage;

public class FindLeadsPageMultilingual extends BasePage {
	public FindLeadsPageMultilingual typeFirstName(String fname) {
		getDriver().findElement(By.xpath("(//input[@name='firstName'])[3]")).sendKeys(fname);
		return this;
	}
	public FindLeadsPageMultilingual clickFindLeadsButton() {
		getDriver().findElement(By.linkText(prop1.getProperty("FindLeadsButton"))).click();
		return this;
	}
	public ViewLeadsPageMultilingual clickFirstLeadId() throws InterruptedException {
		getDriver().findElement(By.xpath("(//a[@href='/crmsfa/control/viewLead?partyId=10127'])")).click();
		Thread.sleep(2000);
		return new ViewLeadsPageMultilingual();

    }
}