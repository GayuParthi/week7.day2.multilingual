package editleadmultilingualpages;

import org.openqa.selenium.By;

import hooksformultilingual.BasePage;

public class HomePage3Multilingual extends BasePage {
	
	public LeadsPageMultilingual clickCRMSFA3() {
		getDriver().findElement(By.linkText("CRM/SFA")).click();
		return new LeadsPageMultilingual();
	}


}
