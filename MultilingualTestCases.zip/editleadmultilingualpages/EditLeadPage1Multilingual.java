package editleadmultilingualpages;

import org.openqa.selenium.By;

import hooksformultilingual.BasePage;

public class EditLeadPage1Multilingual extends BasePage {
	public EditLeadPage1Multilingual clearCompanyName() {
		getDriver().findElement(By.id("updateLeadForm_companyName")).clear();
		return this;
	}
	public EditLeadPage1Multilingual updateCompanyName(String cName) {
		getDriver().findElement(By.id("updateLeadForm_companyName")).sendKeys(cName);
		return this;
	}
	public ViewLeadsPage2Multilingual clickUpdateButton1() {
		getDriver().findElement(By.xpath("(//input[@class='smallSubmit'])")).click();
		return new ViewLeadsPage2Multilingual();
	}

}
