package editleadmultilingualpages;

import org.openqa.selenium.By;

import hooksformultilingual.BasePage;

public class LeadsPageMultilingual extends BasePage{
	public LeadsPageMultilingual clickLeads() {
		getDriver().findElement(By.linkText(prop1.getProperty("Leads"))).click();
		return this;
	}
	public FindLeadsPageMultilingual clickFindLeads() {
		getDriver().findElement(By.linkText(prop1.getProperty("FindLeads"))).click();
		return new FindLeadsPageMultilingual();
	}

}
