package editleadmultilingualpages;

import org.openqa.selenium.By;

import hooksformultilingual.BasePage;

public class ViewLeadsPage2Multilingual extends BasePage {
	public ViewLeadsPage2Multilingual verifyUpdatedCompanyName() {
		String companyName = getDriver().findElement(By.id("viewLead_companyName_sp")).getText();
		System.out.println("Updated Company Name :: "+companyName);
		String firstName = getDriver().findElement(By.id("viewLead_firstName_sp")).getText();
		System.out.println("First Name Of the Lead:: "+firstName);
		return this;
	}

}
