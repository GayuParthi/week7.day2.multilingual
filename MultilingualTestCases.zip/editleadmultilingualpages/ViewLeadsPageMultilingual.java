package editleadmultilingualpages;

import org.openqa.selenium.By;

import hooksformultilingual.BasePage;

public class ViewLeadsPageMultilingual extends BasePage{
	public EditLeadPage1Multilingual clickEditButton() {
		getDriver().findElement(By.linkText(prop1.getProperty("Edit"))).click();
		return new EditLeadPage1Multilingual();
	}

}
