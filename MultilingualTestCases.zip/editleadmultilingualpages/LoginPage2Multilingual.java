package editleadmultilingualpages;

import org.openqa.selenium.By;

import hooksformultilingual.BasePage;

public class LoginPage2Multilingual extends BasePage {
	public LoginPage2Multilingual typeUserName(String username) {
		getDriver().findElement(By.id("username")).sendKeys(username);
		return this;
	}

	public LoginPage2Multilingual typePassword(String password) {
		getDriver().findElement(By.id("password")).sendKeys(password);
		return this; 
	}
	public HomePage3Multilingual clickLogin1() {
		getDriver().findElement(By.className("decorativeSubmit")).click();
		return new HomePage3Multilingual();
	}

}
