package createcontactmultilingualpages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;


import hooksformultilingual.BasePage;

public class MyContactDetailsMultilingual extends BasePage{
	public MyContactDetailsMultilingual typeFirstName(String firstname) {
		WebElement elementFirstName = getDriver().findElement(By.id("firstNameField"));
		elementFirstName.sendKeys(firstname);
		return this;
		
	}
	public MyContactDetailsMultilingual typeLastName(String lastname) {
		getDriver().findElement(By.id("lastNameField")).sendKeys(lastname);
		return this;
	}
	public MyContactDetailsMultilingual typeFirstNameLocal(String fnamelocal) {
		getDriver().findElement(By.id("createContactForm_firstNameLocal")).sendKeys(fnamelocal);
		return this;
	}
	public MyContactDetailsMultilingual typeLastNameLocal(String lnamelocal) {
		getDriver().findElement(By.id("createContactForm_lastNameLocal")).sendKeys(lnamelocal);
		return this;
	}
	public MyContactDetailsMultilingual typeDepartmentName(String dept) {
		getDriver().findElement(By.id("createContactForm_departmentName")).sendKeys(dept);
		return this;
	}
	public MyContactDetailsMultilingual typeDescription(String descrip) {
		getDriver().findElement(By.id("createContactForm_description")).sendKeys(descrip);
		return this;
	}
	public MyContactDetailsMultilingual typeprimaryEmail(String email) {
		getDriver().findElement(By.id("createContactForm_primaryEmail")).sendKeys(email);
		return this;
	}
	
	public ViewContactPageMultilingual clickCreateContactButton() {
		getDriver().findElement(By.className("smallSubmit")).click();
		return new ViewContactPageMultilingual();
	}
	
	

}
