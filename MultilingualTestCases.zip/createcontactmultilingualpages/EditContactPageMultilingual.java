package createcontactmultilingualpages;

import org.openqa.selenium.By;


import hooksformultilingual.BasePage;

public class EditContactPageMultilingual extends BasePage{
	public EditContactPageMultilingual clearAndTypeDescription() {
		getDriver().findElement(By.id("updateContactForm_description")).clear();
		getDriver().findElement(By.id("updateContactForm_importantNote")).sendKeys("Confidential");
		return this;
	}
	public ViewMyCreateContactPageMultilingual clickUpdateContact() {
		getDriver().findElement(By.className("smallSubmit")).click();
		return new ViewMyCreateContactPageMultilingual();
	}

}
