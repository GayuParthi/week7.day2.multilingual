package createcontactmultilingualpages;

import org.openqa.selenium.By;

import hooksformultilingual.BasePage;

public class ContactsPageMultilingual  extends BasePage{
	public ContactsPageMultilingual clickContacts() {
		getDriver().findElement(By.linkText("Contacts")).click();
		return this;
	}
	public MyContactDetailsMultilingual clickCreateContact() {
		getDriver().findElement(By.linkText(prop1.getProperty("contactTab"))).click();
		return new MyContactDetailsMultilingual();
	}

}
