package createcontactmultilingualpages;

import org.openqa.selenium.By;


import hooksformultilingual.BasePage;

public class ViewContactPageMultilingual extends BasePage {
	public EditContactPageMultilingual clickEditButton() {
		getDriver().findElement(By.linkText(prop1.getProperty("Edit"))).click();
		return new EditContactPageMultilingual();
	}

}
