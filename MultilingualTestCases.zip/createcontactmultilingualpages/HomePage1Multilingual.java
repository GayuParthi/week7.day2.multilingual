package createcontactmultilingualpages;

import org.openqa.selenium.By;


import hooksformultilingual.BasePage;

public class HomePage1Multilingual  extends BasePage{
	public ContactsPageMultilingual clickCRMSFA() {
		getDriver().findElement(By.linkText("CRM/SFA")).click();
		return new ContactsPageMultilingual();
	}

}
