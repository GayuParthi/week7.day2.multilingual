package createcontactmultilingualpages;

import org.openqa.selenium.By;


import hooksformultilingual.BasePage;

public class ViewMyCreateContactPageMultilingual extends BasePage {
	public ViewMyCreateContactPageMultilingual verifyContact() {
		String contactName = getDriver().findElement(By.id("viewContact_fullName_sp")).getText();
		System.out.println("Created Contact Name is :: "+contactName);
		return this;
	}

}
