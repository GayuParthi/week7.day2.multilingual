package createleadmultilingualpages;

import hooksformultilingual.BasePage;
import org.openqa.selenium.By;

public class MyHomePageMultingual extends BasePage {
	public MyLeadsPageMultilingual clickLeadsTab2() {
		getDriver().findElement(By.linkText(prop1.getProperty("linkcreatelead"))).click();
		return new MyLeadsPageMultilingual();
	}


}
