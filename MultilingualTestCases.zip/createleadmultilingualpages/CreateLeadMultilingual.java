package createleadmultilingualpages;

import hooksformultilingual.BasePage;
import org.openqa.selenium.By;

public class CreateLeadMultilingual extends BasePage {
	
	public CreateLeadMultilingual typeCompanyName2(String compname) {
		getDriver().findElement(By.xpath("//input[@id='createLeadForm_companyName']")).sendKeys(compname);
		return this;
	}
	
	public CreateLeadMultilingual typeFirstName2(String fname) {
		getDriver().findElement(By.id("createLeadForm_firstName")).sendKeys(fname);
		return this;
	}
	public CreateLeadMultilingual typeLastName2(String lname) {
		getDriver().findElement(By.id("createLeadForm_lastName")).sendKeys(lname);
		return this;
	}
	public CreateLeadMultilingual typeEmailAddress2(String email) {
		getDriver().findElement(By.xpath("//input[@id='createLeadForm_primaryEmail']")).sendKeys(email);
		return this;
	}
	
public ViewLeadsPageMultilingual clickSubmit2() {
	getDriver().findElement(By.xpath("//input[@class='smallSubmit']")).click();
	System.out.println("Submited");
	return new ViewLeadsPageMultilingual();
}
}

