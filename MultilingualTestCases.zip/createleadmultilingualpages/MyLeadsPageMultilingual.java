package createleadmultilingualpages;

import hooksformultilingual.BasePage;
import org.openqa.selenium.By;
public class MyLeadsPageMultilingual extends BasePage {
	public CreateLeadMultilingual clickcreateLead2() {
		getDriver().findElement(By.linkText(prop1.getProperty("linklead"))).click();	
		return new CreateLeadMultilingual();
	}

}
