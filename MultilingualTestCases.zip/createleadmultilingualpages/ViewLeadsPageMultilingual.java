package createleadmultilingualpages;

import org.openqa.selenium.By;

import hooksformultilingual.BasePage;


public class ViewLeadsPageMultilingual extends BasePage{
	public ViewLeadsPageMultilingual verifyFirstName() {
		String text = getDriver().findElement(By.id("viewLead_firstName_sp")).getText();
	    System.out.println("First name = "+text);
		
		return this;
	}
	

}
