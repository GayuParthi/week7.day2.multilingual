package createleadmultilingualpages;

import org.openqa.selenium.By;

import hooksformultilingual.BasePage;

public class LoginPage1Multilingual extends BasePage {
	public LoginPage1Multilingual typeUserName(String username) {
		getDriver().findElement(By.id("username")).sendKeys(username);
		return this;
	}

	public LoginPage1Multilingual typePassword(String password) {
		getDriver().findElement(By.id("password")).sendKeys(password);
		return this; 
	}
	public HomePage2Multilingual clickLogin1() {
		getDriver().findElement(By.className("decorativeSubmit")).click();
		return new HomePage2Multilingual();
	}

}
