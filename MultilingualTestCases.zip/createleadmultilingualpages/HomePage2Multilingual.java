package createleadmultilingualpages;

import hooksformultilingual.BasePage;
import org.openqa.selenium.By;

public class HomePage2Multilingual extends BasePage {
	public MyHomePageMultingual clickCRMSFA2() {
		getDriver().findElement(By.linkText("CRM/SFA")).click();
		return new MyHomePageMultingual();
	}

}



