package tests;

import org.testng.annotations.Test;

import createleadmultilingualpages.LoginPage1Multilingual;
import hooksformultilingual.BasePage;

public class CreateLeadMultilingualTest extends BasePage {
	@Test
	public void createLeadMultilingual() {
		new LoginPage1Multilingual()
		.typeUserName("DemoCsr2")
		.typePassword("crmsfa")
		.clickLogin1()
		.clickCRMSFA2()
		.clickLeadsTab2()
		.clickcreateLead2()
		.typeCompanyName2("TestLeaf")
		.typeFirstName2("Gayathri")
		.typeLastName2("SK")
		.typeEmailAddress2("abc@gmail.com")
		.clickSubmit2()
		.verifyFirstName();
	}

	}


